//Find More Tutorials On WebDriver at -> http://software-testing-tutorials-automation.blogspot.com
package com.stta.SuiteECC;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.stta.utility.Read_XLS;
import com.stta.utility.SuiteUtility;

public class SuiteECCCase6_WaddellReed extends SuiteECCBase{
	Read_XLS FilePath = null;
	String SheetName = null;
	String TestCaseName = null;	
	String ToRunColumnNameTestCase = null;
	String ToRunColumnNameTestData = null;
	String TestDataToRun[]=null;
	static boolean TestCasePass=true;
	static int DataSet=-1;	
	static boolean Testskip=false;
	static boolean Testfail=false;
	SoftAssert s_assert =null;	
	
	@BeforeTest
	public void checkCaseToRun() throws IOException{
		init();			
		//To set .xls file's path In FilePath Variable.
		FilePath = TestCaseListExcelECC;		
		TestCaseName = this.getClass().getSimpleName();	
		//SheetName to check CaseToRun flag against test case.
		SheetName = "TestCasesList";
		//Name of column In TestCasesList Excel sheet.
		ToRunColumnNameTestCase = "CaseToRun";
		//Name of column In Test Case Data sheets.
		ToRunColumnNameTestData = "DataToRun";
		Add_Log.info(TestCaseName+" : Execution started.");
		
		if(!SuiteUtility.checkToRunUtility(FilePath, SheetName,ToRunColumnNameTestCase,TestCaseName)){
			Add_Log.info(TestCaseName+" : CaseToRun = N for So Skipping Execution.");
			SuiteUtility.WriteResultUtility(FilePath, SheetName, "Pass/Fail/Skip", TestCaseName, "SKIP");
			throw new SkipException(TestCaseName+"'s CaseToRun Flag Is 'N' Or Blank. So Skipping Execution Of "+TestCaseName);
		}	
		//To retrieve DataToRun flags of all data set lines from related test data sheet.
		TestDataToRun = SuiteUtility.checkToRunUtilityOfData(FilePath, TestCaseName, ToRunColumnNameTestData);
	}
	
	@Test(dataProvider="SuiteECCCase6_WaddellReedData")
	public void SuiteECCCase6_WaddellReedSDataTest(String DataURL, String DataBrowser, String DataUsername, String DataPassword, String DataSSN, String DataBeginDate, String DataEndDate) throws InterruptedException, IOException{
		
		DataSet++;
		s_assert = new SoftAssert();
		String fileName1_statement = "";

		if(!TestDataToRun[DataSet].equalsIgnoreCase("Y")){	
			Add_Log.info(TestCaseName+" : DataToRun = N for data set line "+(DataSet+1)+" So skipping Its execution.");
			Testskip=true;
			throw new SkipException("DataToRun for row number "+DataSet+" Is No Or Blank. So Skipping Its Execution.");
		}
		
		loadWebBrowser(DataBrowser);		
		driver.get(DataURL);
		userLoginECC(DataUsername, DataPassword);
		
		// Select "Statement (Older than September 20th 2016)"
		Add_Log.info("Logged in");
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(By.name("StatementsImage")));
		driver.findElement(By.name("StatementsImage")).click();
		
		// Select "View Statements"
		Add_Log.info("Selected Statement (Older than September 20th 2016)");
		wait.until(ExpectedConditions.elementToBeClickable(By.name("DocumentViewStmtImage")));
		driver.findElement(By.name("DocumentViewStmtImage")).click();
		
		// Enter Search Criteria and View Document
		Add_Log.info("Selected View Statement");
		wait.until(ExpectedConditions.presenceOfElementLocated((By.name("sttaxid"))));
		driver.findElement(By.name("sttaxid")).sendKeys(DataSSN);

		// Enter Begin Date and End Date 
		driver.findElement(By.name("ststartdate")).clear();
		driver.findElement(By.name("stenddate")).clear();
		driver.findElement(By.name("ststartdate")).sendKeys(DataBeginDate);
		driver.findElement(By.name("stenddate")).sendKeys(DataEndDate);
		
		// Click View document button
		Add_Log.info("Entered SSN, Begin Date, End Date");
		driver.findElement(By.name("enter")).click();

		wait.until(ExpectedConditions.titleContains("eCC System - Statement List"));
		// Get all search result. Verify one of the statement is presented.
		String statementList = driver.findElement(By.xpath("html/body/center/table[2]")).getText();
		if(!statementList.contains("September 30, 2006"))
		{
			s_assert.assertTrue(statementList.contains("September 30, 2006"), "Statement link NOT FOUND: September 30, 2006");
        	Testfail = true;
        	Add_Log.info("FAIL: Statement link NOT FOUND: September 30, 2006");
		}
		else
		{
			Add_Log.info("Statement found: September 30, 2006.");
		}
		if(!statementList.contains("June 30, 2006"))
		{
			s_assert.assertTrue(statementList.contains("June 30, 2006"), "Statement link NOT FOUND: June 30, 2006");
        	Testfail = true;
        	Add_Log.info("FAIL: Statement link NOT FOUND: June 30, 2006");
		}
		else
		{
			Add_Log.info("Statement found: June 30, 2006. Clicking this link");
			// Click on one of the statements i.e June 30, 2006 Statement
			driver.findElement(By.linkText("June 30, 2006")).click();
		}
		
		if(driver.getTitle().contains("Waddell and Reed"))
		{
			try {
				  Thread.sleep(5000);
				} catch(InterruptedException ex) {
				  Thread.currentThread().interrupt();
				}
			fileName1_statement = takeScreenshot(TestCaseName, "1_ViewStatement");
			Add_Log.info("Statement can be opened successufully");
		}
		else 
		{
			Add_Log.info("FAIL: Error occurs upon viewing statement file");
			s_assert.assertTrue(driver.getTitle().contains("Waddell and Reed"), "Error occurs upon viewing statement file");
			Testfail = true;
		}
		// Adding screenshot to report =======================================================================================================================
		Reporter.log("<br>Screenshots of " + TestCaseName);
		if(!fileName1_statement.isEmpty())
		{
			Reporter.log("<br><a href=\""+ fileName1_statement +"\" target=\"_blank\">1 View Statement</a><br>");
		}
		else
		{
			Reporter.log("<br><font color = red>1. Error occurs on Statement file</font><br>");
		}
		//=======================================================================================================================================================
		driver.get(DataURL);
		//driver.close();
		
		
		if(Testfail){
			s_assert.assertAll();		
		}
	
	}
	
	//@AfterMethod method will be executed after execution of @Test method every time.
	@AfterMethod
	public void reporterDataResults(){		
		if(Testskip){
			Add_Log.info(TestCaseName+" : Reporting test data set line "+(DataSet+1)+" as SKIP In excel.");
			//If found Testskip = true, Result will be reported as SKIP against data set line In excel sheet.
			SuiteUtility.WriteResultUtility(FilePath, TestCaseName, "Pass/Fail/Skip", DataSet+1, "SKIP");
		}
		else if(Testfail){
			Add_Log.info(TestCaseName+" : Reporting test data set line "+(DataSet+1)+" as FAIL In excel.");
			//To make object reference null after reporting In report.
			s_assert = null;
			//Set TestCasePass = false to report test case as fail In excel sheet.
			TestCasePass=false;	
			//If found Testfail = true, Result will be reported as FAIL against data set line In excel sheet.
			SuiteUtility.WriteResultUtility(FilePath, TestCaseName, "Pass/Fail/Skip", DataSet+1, "FAIL");			
		}else{
			Add_Log.info(TestCaseName+" : Reporting test data set line "+(DataSet+1)+" as PASS In excel.");
			//If found Testskip = false and Testfail = false, Result will be reported as PASS against data set line In excel sheet.
			SuiteUtility.WriteResultUtility(FilePath, TestCaseName, "Pass/Fail/Skip", DataSet+1, "PASS");
		}
		//At last make both flags as false for next data set.
		Testskip=false;
		Testfail=false;
	}
	
		
	//This data provider method will return column's data one by one In every Iteration.
	@DataProvider
	public Object[][] SuiteECCCase6_WaddellReedData(){
		//Last two columns (DataToRun and Pass/Fail/Skip) are Ignored programatically when reading test data.
		return SuiteUtility.GetTestDataUtility(FilePath, TestCaseName);
	}	
	
	//To report result as pass or fail for test cases In TestCasesList sheet.
	@AfterTest
	public void closeBrowser(){
		closeWebBrowser();
		if(TestCasePass){
			Add_Log.info(TestCaseName+" : Reporting test case as PASS In excel.");
			SuiteUtility.WriteResultUtility(FilePath, SheetName, "Pass/Fail/Skip", TestCaseName, "PASS");
		}
		else{
			Add_Log.info(TestCaseName+" : Reporting test case as FAIL In excel.");
			SuiteUtility.WriteResultUtility(FilePath, SheetName, "Pass/Fail/Skip", TestCaseName, "FAIL");			
		}
	}
}