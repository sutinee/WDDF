//Find More Tutorials On WebDriver at -> http://software-testing-tutorials-automation.blogspot.com
package com.stta.SuiteECC;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import com.stta.utility.Read_XLS;
import com.stta.utility.SuiteUtility;

public class SuiteECCCase4_Ameriprise extends SuiteECCBase{
	Read_XLS FilePath = null;
	String SheetName = null;
	String TestCaseName = null;	
	String ToRunColumnNameTestCase = null;
	String ToRunColumnNameTestData = null;
	String TestDataToRun[]=null;
	static boolean TestCasePass=true;
	static int DataSet=-1;	
	static boolean Testskip=false;
	static boolean Testfail=false;
	SoftAssert s_assert =null;	
	
	@BeforeTest
	public void checkCaseToRun() throws IOException{
		init();			
		//To set .xls file's path In FilePath Variable.
		FilePath = TestCaseListExcelECC;		
		TestCaseName = this.getClass().getSimpleName();	
		//SheetName to check CaseToRun flag against test case.
		SheetName = "TestCasesList";
		//Name of column In TestCasesList Excel sheet.
		ToRunColumnNameTestCase = "CaseToRun";
		//Name of column In Test Case Data sheets.
		ToRunColumnNameTestData = "DataToRun";
		Add_Log.info(TestCaseName+" : Execution started.");
		
		if(!SuiteUtility.checkToRunUtility(FilePath, SheetName,ToRunColumnNameTestCase,TestCaseName)){
			Add_Log.info(TestCaseName+" : CaseToRun = N for So Skipping Execution.");
			SuiteUtility.WriteResultUtility(FilePath, SheetName, "Pass/Fail/Skip", TestCaseName, "SKIP");
			throw new SkipException(TestCaseName+"'s CaseToRun Flag Is 'N' Or Blank. So Skipping Execution Of "+TestCaseName);
		}	
		//To retrieve DataToRun flags of all data set lines from related test data sheet.
		TestDataToRun = SuiteUtility.checkToRunUtilityOfData(FilePath, TestCaseName, ToRunColumnNameTestData);
	}
	
	@Test(dataProvider="SuiteECCCase4_AmeripriseData")
	public void SuiteECCCase4_AmeripriseSDataTest(String DataURL, String DataBrowser, String DataUsername, String DataPassword, String DataAccountNumber, String DataBeginDate) throws InterruptedException, IOException{
		
		DataSet++;
		s_assert = new SoftAssert();
		String fileName1_taxform = "";

		if(!TestDataToRun[DataSet].equalsIgnoreCase("Y")){	
			Add_Log.info(TestCaseName+" : DataToRun = N for data set line "+(DataSet+1)+" So skipping Its execution.");
			Testskip=true;
			throw new SkipException("DataToRun for row number "+DataSet+" Is No Or Blank. So Skipping Its Execution.");
		}
		
		loadWebBrowser(DataBrowser);		
		driver.get(DataURL);
		userLoginECC(DataUsername, DataPassword);
		Add_Log.info("Logged in");
		
		// Select Menu TAX
		WebDriverWait wait = new WebDriverWait(driver, 60);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("html/body/center/table[2]/tbody/tr/td/table/tbody/tr[3]/td/input[8]")));
		driver.findElement(By.xpath("html/body/center/table[2]/tbody/tr/td/table/tbody/tr[3]/td/input[8]")).click();
		Add_Log.info("Selected menu TAX");
		
		// Select "View Tax Form"
		wait.until(ExpectedConditions.elementToBeClickable(By.name("DocumentViewTaxImage")));
		driver.findElement(By.name("DocumentViewTaxImage")).click();
		Add_Log.info("Selected Tax Form");
		
		// Enter Search Criteria and View Document
	
		wait.until(ExpectedConditions.presenceOfElementLocated((By.name("sttaxid"))));
		driver.findElement(By.name("sttaxid")).sendKeys(DataAccountNumber);
		
		// Enter Begin Date and End Date 
		driver.findElement(By.name("ststartdate")).clear();
		driver.findElement(By.name("stenddate")).clear();
		String timeStamp = new SimpleDateFormat("YYYY-MM-dd").format(Calendar.getInstance().getTime());
		driver.findElement(By.name("ststartdate")).sendKeys(DataBeginDate);
		driver.findElement(By.name("stenddate")).sendKeys(timeStamp);
		
		// Click View document button
		driver.findElement(By.name("enter")).click();

		wait.until(ExpectedConditions.titleContains("eCC System - Tax List"));
		// Get all search result. Verify one of the statment is presented.
		String statementList = driver.findElement(By.xpath("html/body/center/table[2]")).getText();
		if(!statementList.contains("December 31, 2003"))
		{
			s_assert.assertTrue(statementList.contains("December 31, 2003"), "Tax Form NOT FOUND: December 31, 2003");
        	Testfail = true;
		}
		
		// Click on on December 31, 2003 link
		driver.findElement(By.linkText("December 31, 2003")).click();	
		Add_Log.info("Tax form is displayed. Click on December 31, 2003");
		try {
			  Thread.sleep(6000);
			} catch(InterruptedException ex) {
			  Thread.currentThread().interrupt();
			}
		// Title in Chrome
		if(driver.getTitle().contains("https://www3.onlinefinancialdocs.com/tf/FANMedia"))
		{
			try {
				  Thread.sleep(5000);
				} catch(InterruptedException ex) {
				  Thread.currentThread().interrupt();
				}
			fileName1_taxform = takeScreenshot(TestCaseName, "1_View Tax Form");
			Add_Log.info("Tax Form can be opened successufully");
		}
		else if(!driver.getTitle().contains("Statement"))
		{
			Add_Log.info("FAIL: Error occurs upon viewing tax form file");
			s_assert.assertTrue(driver.getTitle().contains("https://www3.onlinefinancialdocs.com/tf/FANMedia"), "Error occurs upon viewing tax form file");
			Testfail = true;
		}
		// Title in FF
		if(driver.getTitle().contains("Statement"))
		{
			try {
				  Thread.sleep(6000);
				} catch(InterruptedException ex) {
				  Thread.currentThread().interrupt();
				}
			fileName1_taxform = takeScreenshot(TestCaseName, "1_View Tax Form");
			Add_Log.info("Tax Form can be opened successufully");
		}
		else if(!driver.getTitle().contains("https://www3.onlinefinancialdocs.com/tf/FANMedia"))
		{
			Add_Log.info("FAIL: Error occurs upon viewing tax form file");
			s_assert.assertTrue(driver.getTitle().contains("Statement"), "Error occurs upon viewing tax form file");
			Testfail = true;
		}

		// Adding screenshot to report =======================================================================================================================
		Reporter.log("<br>Screenshots of " + TestCaseName);
		if(!fileName1_taxform.isEmpty())
		{
			Reporter.log("<br><a href=\""+ fileName1_taxform +"\" target=\"_blank\">1 View Statement</a><br>");
		}
		else
		{
			Reporter.log("<br><font color = red>1. Error occurs on Tax Form file</font><br>");
		}
		
		//=======================================================================================================================================================
		driver.get(DataURL);
		if(Testfail){
			s_assert.assertAll();		
		}
	
	}
	
	//@AfterMethod method will be executed after execution of @Test method every time.
	@AfterMethod
	public void reporterDataResults(){		
		if(Testskip){
			Add_Log.info(TestCaseName+" : Reporting test data set line "+(DataSet+1)+" as SKIP In excel.");
			//If found Testskip = true, Result will be reported as SKIP against data set line In excel sheet.
			SuiteUtility.WriteResultUtility(FilePath, TestCaseName, "Pass/Fail/Skip", DataSet+1, "SKIP");
		}
		else if(Testfail){
			Add_Log.info(TestCaseName+" : Reporting test data set line "+(DataSet+1)+" as FAIL In excel.");
			//To make object reference null after reporting In report.
			s_assert = null;
			//Set TestCasePass = false to report test case as fail In excel sheet.
			TestCasePass=false;	
			//If found Testfail = true, Result will be reported as FAIL against data set line In excel sheet.
			SuiteUtility.WriteResultUtility(FilePath, TestCaseName, "Pass/Fail/Skip", DataSet+1, "FAIL");			
		}else{
			Add_Log.info(TestCaseName+" : Reporting test data set line "+(DataSet+1)+" as PASS In excel.");
			//If found Testskip = false and Testfail = false, Result will be reported as PASS against data set line In excel sheet.
			SuiteUtility.WriteResultUtility(FilePath, TestCaseName, "Pass/Fail/Skip", DataSet+1, "PASS");
		}
		//At last make both flags as false for next data set.
		Testskip=false;
		Testfail=false;
	}
	
		
	//This data provider method will return column's data one by one In every Iteration.
	@DataProvider
	public Object[][] SuiteECCCase4_AmeripriseData(){
		//Last two columns (DataToRun and Pass/Fail/Skip) are Ignored programatically when reading test data.
		return SuiteUtility.GetTestDataUtility(FilePath, TestCaseName);
	}	
	
	//To report result as pass or fail for test cases In TestCasesList sheet.
	@AfterTest
	public void closeBrowser(){
		closeWebBrowser();
		if(TestCasePass){
			Add_Log.info(TestCaseName+" : Reporting test case as PASS In excel.");
			SuiteUtility.WriteResultUtility(FilePath, SheetName, "Pass/Fail/Skip", TestCaseName, "PASS");
		}
		else{
			Add_Log.info(TestCaseName+" : Reporting test case as FAIL In excel.");
			SuiteUtility.WriteResultUtility(FilePath, SheetName, "Pass/Fail/Skip", TestCaseName, "FAIL");			
		}
	}
}